import 'package:flutter/material.dart';//import 'routing/routing_page.dart' as route;
import 'package:social_media_for_community/Screens/registrationpage.dart';
import 'package:social_media_for_community/Screens/welcomeScreen.dart';
import 'package:social_media_for_community/Screens/routingPage.dart' as route;
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
          primarySwatch: Colors.brown,
              primaryColor: Colors.brown
      ),
      onGenerateRoute: route.controllers,initialRoute: route.welcomePage,
      title: "Community",
      home: registration()
    );
  }
}
// import 'package:flutter/material.dart';
// import 'package:social_media_for_community/Samples/CheckBox.dart';
// import 'package:social_media_for_community/Samples/ContainerEx.dart';
// import 'package:social_media_for_community/Samples/PopupMenuButton.dart';
// import 'package:social_media_for_community/Samples/RadioButton.dart';
// import 'package:social_media_for_community/Samples/RadioButton2.dart';
// import 'package:social_media_for_community/Samples/ScaffoldEx.dart';
// import 'package:social_media_for_community/Samples/flutterRowColumn.dart';
// import 'package:social_media_for_community/Samples/forms.dart';
// import 'package:social_media_for_community/Samples/mediaQuery.dart';
// import 'package:social_media_for_community/Samples/mediaQuery2.dart';
// import 'package:social_media_for_community/Samples/stackEx.dart';
// void main(){
//   runApp(examples());
// }
// class examples extends StatefulWidget {
//   const examples({Key? key}) : super(key: key);
//   @override
//   State<examples> createState() => _examplesState();
// }
//
//
// class _examplesState extends State<examples> {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         brightness: Brightness.dark,
//           hoverColor: Colors.pink.shade200,
//           primarySwatch: Colors.brown,
//               primaryColor: Colors.brown
//       ),
//       title: "Community",
//       home: Scaffold(
//         body: LoginDemo(),
//       )
//     );
//   }
// }

