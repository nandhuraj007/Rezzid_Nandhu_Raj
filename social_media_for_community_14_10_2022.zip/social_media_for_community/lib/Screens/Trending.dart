import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
class Trending extends StatefulWidget {
  const Trending({Key? key}) : super(key: key);
  @override
  State<Trending> createState() => _TrendingState();
}
class _TrendingState extends State<Trending> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: <Widget>[
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
          ListTile(
            leading: Icon(Icons.manage_accounts),
            title: Text(''),
          ),
        ],
      ),
    );
  }
}
