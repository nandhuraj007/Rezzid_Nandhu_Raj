import 'package:flutter/material.dart';
class UpdatePassword extends StatefulWidget {
  const UpdatePassword({Key? key}) : super(key: key);
  @override
  State<UpdatePassword> createState() => _UpdatePasswordState();
}
class _UpdatePasswordState extends State<UpdatePassword> {
  @override
  bool _isHidden = true;
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

          title: Text(
            "REZZID",style: new TextStyle(
              fontSize: 30.0,
              fontWeight: FontWeight.bold,
              foreground: Paint()..shader = LinearGradient(
                colors: <Color>[
                  Colors.pinkAccent,
                  Colors.deepPurpleAccent,
                  Colors.red
                ],
              ).createShader(Rect.fromLTWH(10.0, 0.0, 200.0, 100.0))
          ),
            //style: TextStyle(color: Colors.white),
          ),
          shadowColor: Colors.redAccent,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: <Color>[Colors.teal, Colors.tealAccent])),
          )
      ),
      body: Container(
          padding: const EdgeInsets.all(40),
          child: ListView(
            children: [
              SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("Change Password",
                  style: TextStyle(
                      fontSize: 20,
                    fontWeight: FontWeight.bold
                ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: TextField(
                  obscureText: _isHidden,
                  decoration: InputDecoration(
                    focusedBorder:OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.black, width: 2.0),
                    ),
                    label:Text("Current Password",style: TextStyle(
                        color: Colors.teal
                    ),
                    ),
                    border: OutlineInputBorder(),
                    hintText: "Enter the Current Password",
                    suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: Icon(
                        _isHidden
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: TextField(
                  obscureText: _isHidden,
                  decoration: InputDecoration(
                    focusedBorder:OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.black, width: 2.0),
                    ),
                    label: Text("New Password",style: TextStyle(
                      color: Colors.teal
                    ),
                    ),
                    border: OutlineInputBorder(),
                    hintText: "Enter The New Password",
                    suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: Icon(
                        _isHidden
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: TextField(
                  obscureText: _isHidden,
                  decoration: InputDecoration(
                    focusedBorder:OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.black, width: 2.0),
                    ),
                    label:Text("Conform Password",style: TextStyle(
                        color: Colors.teal
                    ),
                    ),
                    border: OutlineInputBorder(),
                    hintText: "Reenter Password",
                    suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: Icon(
                        _isHidden
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15,left: 257,bottom: 20),
                child: Center(
                  child: SizedBox(
                    width: 300.0,
                    height: 50,
                    child: ElevatedButton(
                        child: Text("Change Password"),
                        onPressed: (){},
                    ),
                  ),
                ))
            ],
          ),
      ),
    );
  }
  void _togglePasswordView() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }
}
