import 'package:flutter/material.dart';
import 'routing_page.dart' as route;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
      ),
      body: Center(
        child: ElevatedButton(
           child: Text("Go to Login"),
          onPressed: (){
             Navigator.pushNamed(context, route.loginPage);
          },
        ),
      ),
    );
  }
}
