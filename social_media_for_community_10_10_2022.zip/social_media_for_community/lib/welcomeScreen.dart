import 'package:flutter/material.dart';
class welcome extends StatelessWidget {
  const welcome({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Image.asset('assets/images/mylogo.png'),
          Center(
                child: Text("Join the Community",
                  style: TextStyle(
                      fontSize: 38.0,
                      fontWeight: FontWeight.bold,
                      foreground: Paint()..shader = LinearGradient(
                        colors: <Color>[
                          Colors.pinkAccent,
                          Colors.yellow,
                          Colors.red
                          //add more color here.
                        ],
                      ).createShader(Rect.fromLTWH(10.0, 0.0, 200.0, 100.0))
                  ), )
            ),
          Container(
            decoration: new BoxDecoration(
              gradient: new LinearGradient(
                colors: [Colors.red, Colors.blue],
                begin: FractionalOffset.centerLeft,
                end: FractionalOffset.centerRight,
              ),
            ),
            child: FlatButton(
              splashColor: Colors.teal.shade900,
              child: new Icon(Icons.navigate_next),
              onPressed: () {},
            ),
          ),
          ],
      )
    );
  }
}
