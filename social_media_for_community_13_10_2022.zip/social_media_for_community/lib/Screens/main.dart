import 'package:flutter/material.dart';
//import 'routing/routing_page.dart' as route;
import 'package:social_media_for_community/Screens/EditProfileIn.dart';
import 'package:social_media_for_community/Screens/Profile.dart';
import 'package:social_media_for_community/Samples/mediaQuery.dart';
import 'package:social_media_for_community/Screens/Trending.dart';
import 'package:social_media_for_community/Screens/accountSettings.dart';
import 'package:social_media_for_community/Screens/deleteAccount.dart';
import 'package:social_media_for_community/Screens/homepage.dart';
import 'package:social_media_for_community/Screens/loginpage.dart';
import 'package:social_media_for_community/Screens/optionMenu.dart';
import 'package:social_media_for_community/Screens/registrationpage.dart';
import 'package:social_media_for_community/Screens/settings.dart';
import 'package:social_media_for_community/Screens/updatepassword.dart';
import 'package:social_media_for_community/Screens/welcomeScreen.dart';
import 'routingPage.dart' as route;
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
          primarySwatch: Colors.brown,
              primaryColor: Colors.brown
      ),
      onGenerateRoute: route.controllers,initialRoute: route.welcomePage,
      title: "Community",
      home: welcome()
    );
  }
}
// import 'package:flutter/material.dart';
// import 'package:social_media_for_community/Samples/ContainerEx.dart';
// import 'package:social_media_for_community/Samples/ScaffoldEx.dart';
// import 'package:social_media_for_community/Samples/mediaQuery.dart';
// import 'package:social_media_for_community/Samples/mediaQuery2.dart';
// void main(){
//   runApp(examples());
// }
// class examples extends StatefulWidget {
//   const examples({Key? key}) : super(key: key);
//   @override
//   State<examples> createState() => _examplesState();
// }
//
// class _examplesState extends State<examples> {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         brightness: Brightness.dark,
//           primarySwatch: Colors.brown,
//               primaryColor: Colors.brown
//       ),
//       title: "Community",
//       home: example3()
//     );
//   }
// }
//
