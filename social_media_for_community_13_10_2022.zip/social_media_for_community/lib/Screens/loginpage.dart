import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'routingPage.dart' as route;
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);
  @override
  State<Login> createState() => _LoginState();
}
class _LoginState extends State<Login> {
  final formGlobalKey = GlobalKey < FormState > ();
  @override
  bool _isHidden = true;
  final _formKey = GlobalKey<FormState>();
  Widget build(BuildContext context) {
    return Scaffold(
    body: Padding(
      padding: const EdgeInsets.all(0),

      child: Container(
        decoration: BoxDecoration(
          gradient: const RadialGradient(
            colors: [Colors.cyanAccent, Colors.teal],
            radius: 0.75,
            focal: Alignment(0.7, -0.7),
            tileMode: TileMode.clamp,
          ),
          //border corner radius
        ),
        child: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 20,horizontal: 20),
            child: Center(
              child: ListView(
                children:[
                    SizedBox(
                      height: 60,
                    ),
                Center(
                  child: Text("Login Here ",
                    style: new TextStyle(
                        fontSize: 30.0,
                        fontWeight: FontWeight.bold,
                        foreground: Paint()..shader = LinearGradient(
                          colors: <Color>[
                            Colors.pinkAccent,
                            Colors.black,
                            Colors.red
                            //add more color here.
                          ],
                        ).createShader(Rect.fromLTWH(10.0, 0.0, 200.0, 100.0))
                    ),
                  ),
                ),
                    SizedBox(
                      height: 40,
                    ),
                    Column(
                      children: [
                        Form(
                          key: _formKey,
                          child: Padding(
                            padding: const EdgeInsets.all(15),
                            child: TextFormField(
                              decoration: InputDecoration(
                                focusedBorder:OutlineInputBorder(
                                    borderSide: const BorderSide(color: Colors.black, width: 2.0),
                                   ),
                                  border: OutlineInputBorder(),
                                  hintText: "Enter Email",
                                  label: Text("Email"),
                                  icon: Icon(Icons.email,
                                    color: Colors.teal.shade900,)
                              ),
                            ),
                          ),

                        ),
                      ],
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15),
                      child: TextField(
                        obscureText: _isHidden,
                        decoration: InputDecoration(
                          focusedBorder:OutlineInputBorder(
                            borderSide: const BorderSide(color: Colors.black, width: 2.0),
                          ),
                          labelText: 'Password',
                          icon: Icon(Icons.lock),
                          border: OutlineInputBorder(),
                          hintText: "Enter Password",
                          suffix: InkWell(
                            onTap: _togglePasswordView,
                            child: Icon(
                              _isHidden
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: SizedBox(
                        width: 300.0,
                        height: 50,
                          child: ElevatedButton(
                              child: Text("Login"),
                              onPressed: (){
                                Navigator.pushNamed(context, route.homePage);
                              }
                          ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextButton(onPressed: (){
                      //Navigator.pushNamed(context, route.updatePassword);
                    },
                        child: Text(
                          "Forgot Password",
                          style: TextStyle(
                              fontSize: 15,
                              color: Colors.teal.shade900
                          ),
                        )
                    ),
                    Container(
                        padding: EdgeInsets.all(10),
                        child: Center(
                          child: RichText(
                            text: TextSpan(
                                text: 'Need an account?',
                                style: TextStyle(
                                    color: Colors.red, fontSize: 20),
                                children: <TextSpan>[
                                  TextSpan(text: ' Sign up',
                                      style: TextStyle(
                                          color: Colors.blueAccent, fontSize: 20),
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          Navigator.pushNamed(context, route.registrationPage);
                                          // navigate to desired screen
                                        }
                                  )
                                ]
                            ),
                          ),
                        )
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),

    );
  }
void _togglePasswordView() {
  setState(() {
    _isHidden = !_isHidden;
  });
}

}