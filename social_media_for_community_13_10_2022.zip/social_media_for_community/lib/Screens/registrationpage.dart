import 'package:flutter/material.dart';
class registration extends StatefulWidget {
  const registration({Key? key}) : super(key: key);
  @override
  State<registration> createState() => _registrationState();
}
class _registrationState extends State<registration> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: EdgeInsets.all(0),
        width:double.infinity,
        decoration: BoxDecoration(
            gradient: const RadialGradient(
              colors: [Colors.cyanAccent, Colors.teal],
              radius: 0.75,
              focal: Alignment(0.7, -0.7),
              tileMode: TileMode.clamp,
            ),
          //border corner radius
        ),
        padding: EdgeInsets.only(left: 30,top: 20,bottom: 10,right: 20),
        child: ListView(
          children: [
            Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                Padding(padding: EdgeInsets.all(0),
                  child: Text("Lets start your profile",
                      style: new TextStyle(
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          foreground: Paint()..shader = LinearGradient(
                            colors: <Color>[
                              Colors.pinkAccent,
                              Colors.black,
                              Colors.red
                              //add more color here.
                            ],
                          ).createShader(Rect.fromLTWH(0.0, 0.0, 200.0, 100.0))
                      )),
                ),
                SizedBox(
                  height: 30,
                ),
                SizedBox.fromSize(
                  size: Size(70, 70),
                  child: ClipOval(
                    child: Material(
                      color: Colors.black87,
                      child: InkWell(
                        splashColor: Colors.black87,
                        onTap: () {
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(Icons.account_circle),
                             // text
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.only(left: 30,top: 20,bottom: 10,right: 20),
                  child: TextFormField(
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: " Name",
                        label: Text(" Name",
                          style: TextStyle(
                              fontWeight: FontWeight.bold),),
                        icon: Icon(Icons.perm_contact_cal_rounded,
                          color: Colors.black,)
                    ),
                  )
                  ),
                Padding(padding: EdgeInsets.only(left: 30,top: 20,bottom: 10,right: 20),
                    child: TextFormField(
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Email",
                          label: Text("Email",
                            style: TextStyle(
                                fontWeight: FontWeight.bold),),
                          icon: Icon(Icons.email,
                            color: Colors.black,)
                      ),
                    )
                ),
                Padding(padding: EdgeInsets.only(left: 30,top: 20,bottom: 10,right: 20),
                    child: TextFormField(
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Phone Nomber",
                          label: Text("Phone number",
                            style: TextStyle(
                                fontWeight: FontWeight.bold),),
                          icon: Icon(Icons.phone_enabled_rounded,
                            color: Colors.black,)
                      ),
                    )
                ),
                Padding(padding: EdgeInsets.only(left: 30,top: 20,bottom: 10,right: 20),
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: 'Bio',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(vertical: 40,horizontal: 20),
                      ),
                    )
                ),
                Center(
                  child: SizedBox(
                    width: 300.0,
                    height: 50,
                    child: ElevatedButton(
                        child: Text("Register"),
                        onPressed: (){}
                    ),
                  ),
                ),
              ],
            )
          ],
      ),
      ),
    );
  }
}