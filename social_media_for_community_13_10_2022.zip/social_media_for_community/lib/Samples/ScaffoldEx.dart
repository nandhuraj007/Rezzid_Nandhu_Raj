import 'package:flutter/material.dart';
class example3 extends StatefulWidget {
  const example3({Key? key}) : super(key: key);

  @override
  State<example3> createState() => _example3State();
}

class _example3State extends State<example3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(


      appBar: AppBar(
        title: Text("Scaffold example"),
        elevation: 40,
        backgroundColor: Colors.teal,
        bottomOpacity: 33,
      ),


      drawer: Drawer(
        elevation: 15,
        child: Column(
          children: [
            UserAccountsDrawerHeader(
                accountName: Text("Name Here"),
                accountEmail: Text("Email here"),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              radius: 20,
            ),
            ),
            ListTile(
              iconColor: Colors.teal,
              visualDensity: VisualDensity(horizontal: 0.2,vertical: 1.0),//List tile size
              title: Text("Home"),
              leading: Icon(Icons.account_box_outlined),
              onTap: (){},
            ),
            ListTile(
              title: Text("settings"),
              iconColor: Colors.teal,
              visualDensity: VisualDensity(horizontal: 0.2,vertical: 1.0),
              leading: Icon(Icons.settings),
              onTap: (){},
            ),
            ListTile(
              title: Text("Privacy policy"),
              iconColor: Colors.teal,
              visualDensity: VisualDensity(horizontal: 0.2,vertical: 1.0),
              leading: Icon(Icons.privacy_tip_outlined),
              onTap: (){},
            ),
            Divider(
              color: Colors.teal,
            ),
            ListTile(
              iconColor: Colors.teal,
              visualDensity: VisualDensity(horizontal: 0.2,vertical: 1.0),//List tile size
              title: Text("Home"),
              leading: Icon(Icons.account_box_outlined),
              onTap: (){},
            ),
            ListTile(
              iconColor: Colors.teal,
              title: Text("settings"),
              visualDensity: VisualDensity(horizontal: 0.2,vertical: 1.0),
              leading: Icon(Icons.settings),
              onTap: (){},
            ),
            ListTile(
              iconColor: Colors.teal,
              title: Text("Privacy policy"),
              visualDensity: VisualDensity(horizontal: 0.2,vertical: 1.0),
              leading: Icon(Icons.privacy_tip_outlined),
              onTap: (){},
            ),
          ],
        ),
      ),


      floatingActionButton: FloatingActionButton(
        onPressed: (){},
        hoverColor: Colors.teal.shade300,
        child: Icon(Icons.photo_library),
      ),


      persistentFooterButtons: <Widget>[
        RaisedButton(
            onPressed: (){},
          color: Colors.teal,
          child: Icon(Icons.account_circle_rounded),
          hoverColor: Colors.teal.shade900,
        ),
        RaisedButton(
            onPressed: (){},
          color: Colors.teal,
          child: Icon(Icons.ac_unit),
          hoverColor: Colors.teal.shade900,
        ),
      ],

      backgroundColor: Colors.black87,
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      drawerScrimColor: Colors.teal.shade300,//background color of home(remaining portion of drawer) when drawer is clicked
    );
  }
}
