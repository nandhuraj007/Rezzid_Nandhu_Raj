import 'package:flutter/material.dart';
class example2 extends StatefulWidget {
  const example2({Key? key}) : super(key: key);

  @override
  State<example2> createState() => _example2State();
}

class _example2State extends State<example2> {
  @override
  var oriantatation,size,width,height;
  Widget build(BuildContext context) {
    oriantatation=MediaQuery.of(context).orientation;//To get oriantation of the device
    size=MediaQuery.of(context).size;//To get the size of the device
    width=size.width;
    height=size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text("MediaQuery 2"),
      ),
      body:oriantatation==Orientation.portrait?Container(
        color: Colors.blue,
        height: height/4,
        width: width/4,
      ):Container(
        height: height/3,
        width: width/3,
        color: Colors.red,
      ),
    );

  }
}
