import 'package:flutter/material.dart';
class example1 extends StatefulWidget {
  const example1({Key? key}) : super(key: key);

  @override
  State<example1> createState() => _example1State();
}

class _example1State extends State<example1> {
  var height,width,size;
  @override
  Widget build(BuildContext context) {
    size=MediaQuery.of(context).size;//To get he size of the current device
    height=size.height;
    width=size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text("MediaQuery Example"),
      ),
      body: Container(
        color: Colors.teal,
        height: height/2,
        width: width/2,
      ),
    );
  }
}
