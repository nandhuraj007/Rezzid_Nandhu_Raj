import 'package:flutter/material.dart';
import 'routing_page.dart' as route;

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text("Go to register"),
          onPressed: (){
            Navigator.pushNamed(context, route.registerPage);
          },
        ),
      ),
    );
  }
}
