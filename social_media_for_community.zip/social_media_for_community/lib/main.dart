import 'package:flutter/material.dart';
import 'package:social_media_for_community/accountSettings.dart';
import 'package:social_media_for_community/deleteAccount.dart';
import 'package:social_media_for_community/homepage.dart';
import 'package:social_media_for_community/loginpage.dart';
import 'package:social_media_for_community/registrationpage.dart';
import 'package:social_media_for_community/settings.dart';
import 'package:social_media_for_community/updatepassword.dart';
import 'package:social_media_for_community/welcomeScreen.dart';
void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
          primarySwatch: Colors.brown,
              primaryColor: Colors.brown
      ),
      title: "Community",
      home: welcome()
    );
  }
}

