import 'package:flutter/material.dart';
class UpdatePassword extends StatefulWidget {
  const UpdatePassword({Key? key}) : super(key: key);
  @override
  State<UpdatePassword> createState() => _UpdatePasswordState();
}
class _UpdatePasswordState extends State<UpdatePassword> {
  @override
  bool _isHidden = true;
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
            onPressed: () {
            },
            icon: Icon(Icons.arrow_back),
          ),
          title: Text(
            "Change Password",
            style: TextStyle(color: Colors.white),
          ),
          shadowColor: Colors.redAccent,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: <Color>[Colors.teal, Colors.tealAccent])),
          )
      ),
      body: Container(
          padding: const EdgeInsets.all(40),
          child: Column(
            children: [
              SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: TextField(
                  obscureText: _isHidden,
                  decoration: InputDecoration(
                    focusedBorder:OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.black, width: 2.0),
                    ),
                    labelText: 'Current Password',
                    border: OutlineInputBorder(),
                    hintText: "Enter the Current Password",
                    suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: Icon(
                        _isHidden
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: TextField(
                  obscureText: _isHidden,
                  decoration: InputDecoration(
                    focusedBorder:OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.black, width: 2.0),
                    ),
                    labelText: 'New Password',
                    border: OutlineInputBorder(),
                    hintText: "Enter The New Password",
                    suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: Icon(
                        _isHidden
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: TextField(
                  obscureText: _isHidden,
                  decoration: InputDecoration(
                    focusedBorder:OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.black, width: 2.0),
                    ),
                    labelText: 'Conform Password',
                    border: OutlineInputBorder(),
                    hintText: "Conform Password",
                    suffix: InkWell(
                      onTap: _togglePasswordView,
                      child: Icon(
                        _isHidden
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15,left: 257,bottom: 20),
                child: Center(
                  child: SizedBox(
                    width: 300.0,
                    height: 50,
                    child: ElevatedButton(
                        child: Text("Change Password"),
                        onPressed: (){},
                    ),
                  ),
                ))
            ],
          ),
      ),
    );
  }
  void _togglePasswordView() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }
}
