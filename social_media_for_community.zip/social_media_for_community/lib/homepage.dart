import 'package:flutter/material.dart';
import 'package:social_media_for_community/loginpage.dart';
class homepage extends StatefulWidget {
  const homepage({Key? key}) : super(key: key);
  @override
  State<homepage> createState() => _homepageState();
}
class _homepageState extends State<homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("RezziD"),
          actionsIconTheme: IconThemeData(
              color: Colors.black,
              size: 36),
              shadowColor: Colors.redAccent,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: <Color>[Colors.teal, Colors.tealAccent])),
          )
      ),
        body: ListView(
          children: [
            Column(
              children: [
                Container(
                  width: 500,
                  height: 300,
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Card(
                      child: Stack(
                        children: [
                           Icon(Icons.account_box_outlined)
                        ],
                      ),
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: Colors.teal.withOpacity(1.0),
                    ),
                  ),
                ),
                Container(
                  width: 500,
                  height: 300,
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Card(
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: Colors.teal.withOpacity(1.0),
                    ),
                  ),
                ),
                Container(
                  width: 500,
                  height: 300,
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Card(
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: Colors.teal.withOpacity(1.0),
                    ),
                  ),
                ),
                Container(
                  width: 500,
                  height: 300,
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Card(
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: Colors.teal.withOpacity(1.0),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
        endDrawer: Drawer(
          child: ListView(
            children: <Widget>[
              UserAccountsDrawerHeader(
                accountName: Text("Nandhu raj"),
                accountEmail: Text("nandhuraj@gmail.com"),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Colors.teal,
                ),),
              ListTile(
                leading: Icon(Icons.account_circle,
                  color: Colors.teal.shade600,),
                title: Text("Profile"),
                hoverColor: Colors.teal,
                onTap: () {

                },
              ),
              ListTile(
                leading: Icon(Icons.settings,
                  color: Colors.teal.shade600,),
                title: Text("Settings"),
                hoverColor: Colors.teal,
                onTap: () {
                },
              ),
              ListTile(
                leading: Icon(Icons.contact_phone,
                  color: Colors.teal.shade600,),
                title: Text("Ask"),
                hoverColor: Colors.teal,
                onTap: () {
                },
              ),
              ListTile(
                leading: Icon(Icons.group_add,
                  color: Colors.teal.shade600,),
                title: Text("Pick a friend"),
                hoverColor: Colors.teal,
                onTap: () {
                },
              ),
              ListTile(
                leading: Icon(Icons.privacy_tip_outlined,
                  color: Colors.teal.shade600,),
                title: Text("Privacy Policy"),
                hoverColor: Colors.teal,
                onTap: () {
                },
              ),
              ListTile(
                leading: Icon(Icons.logout_outlined,
                  color: Colors.teal.shade600,),
                title: Text("Logout"),
                hoverColor: Colors.redAccent,
                onTap: () {
                },
                //tileColor: Colors.black,
              ),
            ],
          ),
        ),
      bottomNavigationBar: BottomNavigationBar(
        items: const<BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.trending_up,
            size: 30,
            color: Colors.teal,),

            label: '',),
          BottomNavigationBarItem(
            icon: Icon(Icons.groups_rounded,
              size: 30,
              color: Colors.teal,),
            label: '',),
          BottomNavigationBarItem(
            icon: Icon(Icons.search_outlined,
              size: 30,
              color: Colors.teal,),
            label: '',),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications_active,
              size: 30,
              color: Colors.teal,),
            label: '',)
        ]
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.inbox),
        hoverElevation: 50,
        onPressed: () {},
        hoverColor: Colors.teal.shade100,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniCenterFloat,

    );
}}
