package com.example.social_media_for_community

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
