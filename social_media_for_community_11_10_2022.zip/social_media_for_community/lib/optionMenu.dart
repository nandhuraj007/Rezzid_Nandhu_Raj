import 'package:flutter/material.dart';
//import 'package:selection_menu/selection_menu.dart';
class Options extends StatefulWidget {
  const Options({Key? key}) : super(key: key);

  @override
  State<Options> createState() => _OptionsState();
}

class _OptionsState extends State<Options> {
  String dropdownvalue = 'Programming';
  var items = [
    'Science and Technology',
    'Programming',
    'Photography',
    'Medical',
    'Construction',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(80),
          child: Column(
           // mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 70,),
              Text("Selct your community to join according to your profession/fassion",
                style: TextStyle(fontSize: 16),),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: DropdownButton(
                  iconSize: 15,
                  elevation: 15,
                  value: dropdownvalue,
                  icon: const Icon(Icons.keyboard_arrow_down_rounded),
                  items: items.map((String items) {
                    return DropdownMenuItem(
                      value: items,
                      child: Text(items,style: TextStyle(fontSize: 21,fontWeight: FontWeight.bold)),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      dropdownvalue = newValue!;
                    });
                  },
                ),
              ),
              SizedBox(
                width: 230.0,
                height: 30,
                child: ElevatedButton(
                    child: Text("GO"),
                    onPressed: (){}
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
