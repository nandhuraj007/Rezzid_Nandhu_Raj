//import 'package:flutter/material.dart';
import 'dart:js';

import 'package:flutter/material.dart';
import 'package:social_media_for_community/routing/homepage.dart';
import 'package:social_media_for_community/routing/login.dart';
import 'package:social_media_for_community/routing/register.dart';
const String loginPage="login";
const String homePage="home";
const String registerPage="register";
void login(){}
void home(){}
void register(){}
Route<dynamic> controller(RouteSettings settings){
  switch(settings.name){
    case loginPage:
      {
        return MaterialPageRoute(builder: (context)=> LoginPage());
      }
    case homePage:
      {
        return MaterialPageRoute(builder: (context)=> HomePage());
      }
    case registerPage:
      {
        return MaterialPageRoute(builder: (context)=> RegisterPage());
      }
    default:
      throw ('no page found');
  }
}