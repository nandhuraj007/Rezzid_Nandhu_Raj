import 'package:flutter/material.dart';
import 'routing_page.dart' as route;
class RegisterPage extends StatefulWidget {
  const RegisterPage({Key? key}) : super(key: key);

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Register"),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text("Back"),
          onPressed: (){
            Navigator.pushNamed(context, route.homePage);
          },
        ),
      ),
    );
  }
}
